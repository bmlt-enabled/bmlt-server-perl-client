# BmltClient::Object::ValidationError

## Load the model package
```perl
use BmltClient::Object::ValidationError;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **string** |  | 
**errors** | **HASH[string,ARRAY[string]]** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


