# BmltClient::Object::User

## Load the model package
```perl
use BmltClient::Object::User;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **string** |  | 
**type** | **string** |  | 
**display_name** | **string** |  | 
**description** | **string** |  | 
**email** | **string** |  | 
**owner_id** | **string** |  | 
**id** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


